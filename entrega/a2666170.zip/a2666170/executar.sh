#!/usr/bin/env bash
# Executa o sistema de agendamento de salas (Linux / macOS).
# Uso: ./executar.sh [servidor | cliente | servidor-gui | cliente-gui]
# Sem argumento, mostra um menu.

cd "$(dirname "$0")" || exit 1

if ! command -v java >/dev/null 2>&1; then
    echo "Java nao encontrado. Instale o JDK 26 (https://adoptium.net) e tente de novo."
    exit 1
fi

VERSAO=$(java -version 2>&1 | head -n 1 | sed -E 's/.*version "([0-9]+).*/\1/')
if [[ "$VERSAO" =~ ^[0-9]+$ ]] && (( VERSAO < 26 )); then
    echo "Este programa precisa do Java 26 ou superior. Versao encontrada: $VERSAO."
    echo "Instale o JDK 26 (https://adoptium.net) e tente de novo."
    exit 1
fi

MODO="$1"
if [ -z "$MODO" ]; then
    echo "Sistema de Agendamento de Salas"
    echo "1 - Servidor (console)"
    echo "2 - Cliente (console)"
    echo "3 - Servidor (interface grafica)"
    echo "4 - Cliente (interface grafica)"
    read -r -p "Opcao: " OPCAO
    case "$OPCAO" in
        1) MODO=servidor ;;
        2) MODO=cliente ;;
        3) MODO=servidor-gui ;;
        4) MODO=cliente-gui ;;
        *) echo "Opcao invalida."; exit 1 ;;
    esac
fi

CP="lib/*"
case "$MODO" in
    servidor)     CLASSE=br.edu.utfpr.sd.servidor.Servidor ;;
    cliente)      CLASSE=br.edu.utfpr.sd.cliente.Cliente ;;
    servidor-gui) CLASSE=br.edu.utfpr.sd.servidor.ServidorGui ;;
    cliente-gui)  CLASSE=br.edu.utfpr.sd.cliente.ClienteGui ;;
    *) echo "Modo invalido: $MODO. Use servidor, cliente, servidor-gui ou cliente-gui."; exit 1 ;;
esac

if [[ "$MODO" == *-gui ]]; then
    if [ "$(uname -s)" != "Linux" ]; then
        echo "A interface grafica foi empacotada so para Linux e Windows. Use o modo console."
        exit 1
    fi
    CP="$CP:lib/javafx/*:lib/javafx/linux/*"
fi

exec java --enable-native-access=ALL-UNNAMED -cp "$CP" "$CLASSE"
