# Sistema de Agendamento de Salas — Entrega Parcial 01

Sistemas Distribuídos — UTFPR
Aluno: Atos Aires Arruda (RA a2666170)

Sistema cliente/servidor de agendamento de salas. Cliente e servidor trocam mensagens **JSON sobre TCP** (biblioteca Gson), seguindo o protocolo da turma: https://pedrosalvatori.github.io/protocolo-reserva-salas/

Esta entrega cobre o **CRUD do usuário comum, com login e logout**:

| Operação | Mensagem enviada pelo cliente | Precisa de login |
|---|---|---|
| Cadastro (C) | `register` | não |
| Login | `login` | não |
| Leitura (R) do próprio cadastro | `read_user` | sim |
| Atualização (U) do próprio cadastro | `update_user` | sim |
| Exclusão (D) do próprio cadastro | `delete_user` | sim |
| Logout | `logout` | sim |

Cliente e servidor exibem no console **todas as mensagens JSON enviadas e recebidas**. O servidor pede a **porta** ao iniciar, e o cliente pede o **IP** e a **porta** do servidor.

---

## 1. Requisito: Java 26

O único programa necessário é o **JDK 26** (ou JRE 26). Todas as bibliotecas já estão neste zip, e **não é preciso Maven nem internet** para executar.

- Download: https://adoptium.net (Temurin 26). No Linux também serve o pacote `openjdk-26-jdk` da distribuição.
- Confira a versão com:

  ```
  java -version
  ```

  A primeira linha deve mostrar `26` ou superior. Com uma versão anterior, o Java mostra `UnsupportedClassVersionError`.

## 2. Conteúdo do zip

```
a2666170/
├── README.md            este arquivo
├── executar.sh          inicia o programa no Linux / macOS
├── executar.bat         inicia o programa no Windows
├── lib/                 programa compilado e bibliotecas
│   ├── agenda-salas-0.1.0.jar      o sistema (cliente e servidor)
│   ├── gson-2.14.0.jar             JSON
│   ├── sqlite-jdbc-3.50.3.0.jar    banco de dados SQLite
│   ├── slf4j-*.jar, error_prone_annotations-*.jar   dependências das anteriores
│   └── javafx/                     interface gráfica (JavaFX 26.0.2)
│       ├── javafx-base / javafx-controls
│       ├── linux/javafx-graphics-26.0.2-linux.jar
│       └── windows/javafx-graphics-26.0.2-win.jar
└── codigo-fonte/        código-fonte completo (projeto Maven)
    ├── pom.xml
    └── src/
        ├── main/java/br/edu/utfpr/sd/
        │   ├── comum/     ConexaoJson (envio, recebimento e log dos JSONs), Json, ValidacaoCadastro
        │   ├── servidor/  Servidor (console), TratadorCliente (uma thread por cliente),
        │   │              BancoDados (SQLite), ServidorApp/ServidorGui (interface gráfica)
        │   ├── cliente/   Cliente (console), ClienteApp/ClienteGui (interface gráfica)
        │   └── gui/       PainelJson (área de JSONs das duas interfaces)
        ├── main/resources/   estilo.css das interfaces
        ├── test/java/        testes automatizados (JUnit)
        └── servidor_eco_tcp_json/   código base fornecido na disciplina
```

## 3. Como executar

Extraia o zip e abra um terminal **dentro da pasta `a2666170`**.

**Linux / macOS**

```
./executar.sh servidor
./executar.sh cliente
```

**Windows** (Prompt de Comando ou PowerShell)

```
executar.bat servidor
executar.bat cliente
```

Sem argumento, os scripts mostram um menu. No Windows também dá para abrir o `executar.bat` com duplo clique.

| Argumento | O que abre |
|---|---|
| `servidor` | servidor no console |
| `cliente` | cliente no console |
| `servidor-gui` | servidor com interface gráfica (JavaFX) |
| `cliente-gui` | cliente com interface gráfica (JavaFX) |

A interface gráfica foi empacotada para **Linux e Windows (64 bits)**. No macOS, use os modos de console. As interfaces usam as mesmas classes de rede do console, então também exibem no terminal todos os JSONs trocados. Ao abrir uma interface, o terminal mostra o aviso `Unsupported JavaFX configuration: classes were loaded from 'unnamed module'`; ele é esperado, porque o JavaFX roda pelo classpath, e não afeta o funcionamento.

**Sem os scripts.** O comando equivalente, executado na pasta `a2666170`:

```
java --enable-native-access=ALL-UNNAMED -cp "lib/*" br.edu.utfpr.sd.servidor.Servidor
java --enable-native-access=ALL-UNNAMED -cp "lib/*" br.edu.utfpr.sd.cliente.Cliente
```

No Windows, para a interface gráfica, troque o classpath por `"lib\*;lib\javafx\*;lib\javafx\windows\*"` e a classe por `br.edu.utfpr.sd.servidor.ServidorGui` ou `br.edu.utfpr.sd.cliente.ClienteGui`. No Linux, use `"lib/*:lib/javafx/*:lib/javafx/linux/*"`.

## 4. Roteiro de teste (cliente e servidor na mesma máquina)

**Terminal 1 — servidor**

```
./executar.sh servidor        (Windows: executar.bat servidor)
```

Digite a porta, por exemplo `23456`. O servidor responde `Servidor carregado na porta 23456. Aguardando conexoes...`.

**Terminal 2 — cliente**

```
./executar.sh cliente         (Windows: executar.bat cliente)
```

Informe o IP `127.0.0.1` e a mesma porta. O cliente mostra um menu numerado. Um roteiro que passa por todas as operações:

| Passo | Opção do menu | Dados | Resposta esperada |
|---|---|---|---|
| 1 | `1` Cadastrar (register) | email `joao.silva@email.com`, usuário `joao`, senha `senha123` | `201` Usuario cadastrado com sucesso |
| 2 | `2` Login | mesmo email e senha | `200` e um token |
| 3 | `3` Ler meu cadastro (read_user) | — | `200` com usuário, email, role e data de criação |
| 4 | `4` Atualizar (update_user) | novo usuário `joana`, senha em branco | `200` |
| 5 | `3` Ler meu cadastro | — | `200`, agora com usuário `joana` |
| 6 | `6` Logout | — | `200` |
| 7 | `3` Ler meu cadastro | — | o cliente avisa que não há sessão |
| 8 | `2` Login, depois `5` Apagar (delete_user) | senha `senha123` | `200`; um novo login com esse email passa a falhar com `401` |

Casos de erro que vale testar:
- cadastrar de novo o mesmo email: `409`;
- login com senha errada: `401`;
- atualizar com usuário e senha em branco: `400` Nenhum dado para atualizar;
- cadastro com email, usuário ou senha fora do formato do protocolo: o cliente mostra o problema e não envia. Para ver o `400` do servidor, envie o JSON pela opção `7`, por exemplo `{"op":"register","email":"x","user":"joao","password":"senha123"}`;
- opção `7` (Enviar JSON manual): manda uma linha exatamente como foi digitada, para ver como o servidor trata JSON inválido, campos faltando ou operação desconhecida.

Em cada passo, os dois terminais mostram as mensagens, por exemplo:

```
[Cliente] enviou para 127.0.0.1:23456: {"op":"login","email":"joao.silva@email.com","password":"senha123"}
[Cliente] recebeu de 127.0.0.1:23456: {"op":"login_response","status":"200","message":"Login realizado com sucesso","token":"...","role":"user"}
```

## 5. Teste entre máquinas diferentes

1. Inicie o servidor e escolha uma porta acima de 1024.
2. Descubra o IP da máquina do servidor (`hostname -I` no Linux, `ipconfig` no Windows) e use esse IP no cliente da outra máquina. `127.0.0.1` só funciona na própria máquina.
3. Se houver firewall, libere a porta TCP escolhida (no Ubuntu: `sudo ufw allow 23456/tcp`; no Windows, aceite o aviso do Firewall quando o Java abrir a porta).

O cliente funciona com o servidor de qualquer colega que siga o protocolo, e o servidor atende o cliente de qualquer colega.

## 6. Comportamento do servidor

- Uma thread para cada cliente conectado.
- Usuários e sessões ficam em SQLite, no arquivo `agenda.db` criado na pasta `a2666170`. As senhas são guardadas com hash. Para recomeçar com o banco vazio, pare o servidor e apague o `agenda.db`.
- No login, gera um token de 64 caracteres hexadecimais. Cada usuário tem uma única sessão ativa, e o token expira após 30 minutos sem uso.
- Conexões sem atividade por 300 segundos são fechadas.
- **Decisão de projeto que difere do protocolo (regra 1.9):** qualquer encerramento da conexão (cliente fechado sem logout, processo encerrado, queda de rede ou timeout de inatividade) é tratado como **logout**: o token daquela conexão é invalidado e um novo login funciona na hora.
- Toda resposta traz `op`, `status` e `message`, com os textos definidos no protocolo.

**Interface gráfica do servidor:** digite a porta e clique em *Iniciar servidor*. A tela mostra o total de threads, conexões e mensagens; a tabela de threads (cliente, estado, usuário logado, última operação e status); a conversa da thread selecionada; e o log de todas as threads. A aba *Banco de dados* mostra os usuários cadastrados.

**Interface gráfica do cliente:** informe IP e porta e clique em *Conectar*. A aba *Login* tem login e cadastro; a aba *Minha conta*, liberada após o login, tem `read_user`, `update_user` (campo em branco = não alterar), `delete_user` e `logout`. À direita fica a área com todos os JSONs enviados e recebidos.

## 7. Compilar a partir do código-fonte (opcional)

O programa já vem compilado em `lib/agenda-salas-0.1.0.jar`. Para compilar de novo:

**Com Maven 3.9+** (baixa as dependências da internet), dentro de `codigo-fonte`:

```
mvn package                    compila e roda os testes automatizados
mvn -q exec:java@servidor      servidor no console
mvn -q exec:java@cliente       cliente no console
mvn -q exec:java@servidor-gui  servidor com interface gráfica
mvn -q exec:java@cliente-gui   cliente com interface gráfica
```

Os testes automatizados (`mvn test`) sobem um servidor numa porta livre com um banco temporário e conferem as respostas de cada operação: sucesso, dados inválidos, token inválido, conflitos e erros de protocolo.

**Sem Maven e sem internet** (Linux, na pasta `a2666170`), usando as bibliotecas do zip:

```
mkdir -p classes
javac -d classes -cp "lib/*:lib/javafx/*:lib/javafx/linux/*" $(find codigo-fonte/src/main/java -name "*.java")
cp -r codigo-fonte/src/main/resources/* classes/
java --enable-native-access=ALL-UNNAMED -cp "classes:lib/gson-2.14.0.jar:lib/sqlite-jdbc-3.50.3.0.jar:lib/slf4j-api-2.0.17.jar:lib/slf4j-nop-2.0.17.jar" br.edu.utfpr.sd.servidor.Servidor
```

## 8. Observações sobre as bibliotecas

- Para caber no limite de 20 MB, o `sqlite-jdbc-3.50.3.0.jar` foi reduzido: ficaram só os binários nativos de Linux (x86_64 e aarch64), Windows (x86_64) e macOS (x86_64 e aarch64). As classes Java não foram alteradas.
- Pelo mesmo motivo, o JavaFX traz `javafx-base` e `javafx-controls` uma única vez (são Java puro) e o `javafx-graphics`, que contém código nativo, em uma versão para Linux e outra para Windows.

## 9. Problemas comuns

| Sintoma | Causa provável |
|---|---|
| `UnsupportedClassVersionError` | Java anterior ao 26. Instale o JDK 26. |
| `Permission denied` ao rodar `./executar.sh` | Rode `chmod +x executar.sh` ou use `bash executar.sh servidor`. |
| `Erro: a porta ... esta ocupada` | Outro programa usa a porta. Escolha outra. |
| Cliente mostra `Erro de comunicacao` | IP ou porta errados, servidor parado ou porta bloqueada pelo firewall. |
