@echo off
rem Executa o sistema de agendamento de salas (Windows).
rem Uso: executar.bat [servidor ^| cliente ^| servidor-gui ^| cliente-gui]
rem Sem argumento (ou com duplo clique), mostra um menu.
setlocal
cd /d "%~dp0"
chcp 65001 >nul

where java >nul 2>&1
if errorlevel 1 (
    echo Java nao encontrado. Instale o JDK 26 ^(https://adoptium.net^) e tente de novo.
    pause
    exit /b 1
)

set "MODO=%~1"
if not "%MODO%"=="" goto escolher_classe

echo Sistema de Agendamento de Salas
echo 1 - Servidor (console)
echo 2 - Cliente (console)
echo 3 - Servidor (interface grafica)
echo 4 - Cliente (interface grafica)
set /p "OPCAO=Opcao: "
if "%OPCAO%"=="1" set "MODO=servidor"
if "%OPCAO%"=="2" set "MODO=cliente"
if "%OPCAO%"=="3" set "MODO=servidor-gui"
if "%OPCAO%"=="4" set "MODO=cliente-gui"

:escolher_classe
set "CP=lib\*"
set "CLASSE="
if /i "%MODO%"=="servidor" set "CLASSE=br.edu.utfpr.sd.servidor.Servidor"
if /i "%MODO%"=="cliente" set "CLASSE=br.edu.utfpr.sd.cliente.Cliente"
if /i "%MODO%"=="servidor-gui" set "CLASSE=br.edu.utfpr.sd.servidor.ServidorGui"
if /i "%MODO%"=="cliente-gui" set "CLASSE=br.edu.utfpr.sd.cliente.ClienteGui"
if /i "%MODO:~-4%"=="-gui" set "CP=lib\*;lib\javafx\*;lib\javafx\windows\*"

if "%CLASSE%"=="" (
    echo Opcao invalida. Use servidor, cliente, servidor-gui ou cliente-gui.
    pause
    exit /b 1
)

java --enable-native-access=ALL-UNNAMED -cp "%CP%" %CLASSE%
pause
